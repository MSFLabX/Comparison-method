# SSRNET
SSRNET for hyperspectral and multispectral image fusion.
This is the code of X. Zhang, W. Huang, Q. Wang, and X. Li, “SSR-NET: Spatial-Spectral Reconstruction Network for Hyperspectral and Multispectral Image Fusion,”  IEEE Transactions on Geoscience and Remote Sensing (T-GRS), 2020.
