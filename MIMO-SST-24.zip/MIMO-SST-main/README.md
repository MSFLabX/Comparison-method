# MIMO-SST
The steps for using the MIMO-SST code are as follows:
1. Data Preprocessing:
The first step involves preprocessing the data, using the DataSet file to generate an .h5 file.
2. Model Training:
The second step is to train the model using the generated .h5 file with the train file.
3. Model Testing:
The third step involves testing the trained model using the test file.
