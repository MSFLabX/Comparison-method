# Low-Rank-Transformer-For-High-Resolution-Hyperspectral-Computational-Imaging
The code for 《Low-Rank Transformer For High-Resolution Hyperspectral Computational Imaging》

NOTE: The image size during testing needs to be consistent with the training size.
